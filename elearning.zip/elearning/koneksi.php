<?php
    $koneksi = mysqli_connect("localhost","root","","db_elearning") or die("Koneksi Gagal");
?>